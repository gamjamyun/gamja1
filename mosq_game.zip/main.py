import pygame
from random import*
from math import*
pygame.init()
screen_width = 600 #가로
screen_height = 800 #세로크기
screen=pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("moskillto") #타이틀
clock=pygame.time.Clock()
jangjun=pygame.mixer.Sound("resources/sounds/총 장전 소리.mp3")
mosq_sound=pygame.mixer.Sound("resources/sounds/mosq_sound.mp3")
class obj:
        def __init__(self):
            self.x = 0
            self.y = 0
            self.v = 0
        def put_img(self, address):
            if address[-3:] == "png":
                self.img = pygame.image.load(address).convert_alpha()
            else :
                self.img = pygame.image.load(address)
            self.sx, self.sy = self.img.get_size()
        def sizeset(self, sx, sy):
            self.img = pygame.transform.scale(self.img, (sx, sy))
            self.sx, self.sy = self.img.get_size()
        def disp(self):
            screen.blit(self.img, (self.x,self.y))
#텍스트 설정
def show_text(text, font, screen, x, y):
    textobj=font.render(text,True,(0,0,0),(255,255,255))
    textrect=textobj.get_rect()
    textrect.topleft=(x,y)
    screen.blit(textobj,textrect)
def put(x,i):
    if i<10:
        x=pygame.image.load( 'resources/ani1/이름 없는 노트북-0'+str(i)+'.jpg')
    elif i>=10:
        x=pygame.image.load('resources/ani1/이름 없는 노트북-'+str(i)+'.jpg')
    x=pygame.transform.scale(x, (600, 800))
    screen.blit(x,(0,-100))
desk=pygame.image.load( 'resources/ani1/desk.jpg')
desk=pygame.transform.scale(desk, (600, 800))
k=0
x=4
phase=-1
a=1
sk=0
i=0
running = True 
while running:
    dt=clock.tick(60)
    k=k+1
    for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                running = False 
    for i in range(1,58):
        if k>=x*i and k<x*(i+1):
            put (a,i+3)
        i+=1
    if k==40:
        mosq_sound.play()
    if k==210:
        jangjun.play()
    if k==350:
        phase=0
    if event.type == pygame.KEYUP:
                if event.key == pygame.K_l:
                    sk=sk+1
    if sk>5:
        phase=0
    pygame.display.update()# 게임화면 다시그리기
    if phase==0:
            break
##################################$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$##########################################
###########################################################################################################################
###################################################################################$$$$$$$$$$$$$$$$$$$$$!!!!!!!!!!!!@@####
######################################################################################################################
if phase==0:
    import pygame
    from random import*
    from math import*
    pygame.init()
    screen_width = 600 #가로
    screen_height = 400 #세로크기
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto") #타이틀
    phase=0

    #fps
    clock=pygame.time.Clock()
    #배경이미지
    room=pygame.image.load("resources/images/room.png")
    #총
    shot=5000
    shortcut=1
    cow_hp=100
    gun = pygame.image.load("resources/images/gun.png")
    gun_size = gun.get_rect().size#이미지 크기를 구해옴
    gun_width = gun_size[0] #케릭터 가로크기
    gun_height = gun_size[1] #케릭터 세로크기 
    gun_x_pos = (screen_width-gun_width)/2 #화면 가로가운데위치
    gun_y_pos = screen_height-gun_height #세로 가운데
    gun2 = pygame.image.load("resources/images/gun2.png")
    gunsound=pygame.mixer.Sound("resources/sounds/gunsound.mp3")
    coin_sound=pygame.mixer.Sound("resources/sounds/Coin.wav")
    #모기
    [m1dead,m2dead,m3dead,k,qwe]=[0,0,0,0,0]
    mosq_sound=pygame.mixer.Sound("resources/sounds/mosq_sound.mp3")
    mosq = pygame.image.load("resources/images/mosq2.png")
    mosq2=pygame.image.load("resources/images/mosq2.png")
    mosq3=pygame.image.load("resources/images/mosq2.png")
    blood=pygame.image.load("resources/images/blood.png")
    blood=pygame.transform.scale(blood,(30,30))
    [mosq_width,mosq_height]=[30,30]
    [mosq_x_pos,mosq_y_pos]=[randrange(50,550),randrange(50,550)]
    [mosq2_x_pos,mosq2_y_pos]=[randrange(50,550),randrange(50,550)]
    [mosq3_x_pos,mosq3_y_pos]=[randrange(50,550),randrange(50,550)]
    m1dead_x,m1dead_y,m2dead_x,m2dead_y,m3dead_x,m3dead_y,=(1000,1000,1000,1000,1000,1000)
    #텍스트 설정
    def show_text(text, font, screen, x, y):
        textobj=font.render(text,True,(0,0,0),(255,255,255))
        textrect=textobj.get_rect()
        textrect.topleft=(x,y)
        screen.blit(textobj,textrect)
    coin=0
    running = True 
    while running:
        k=k+1    
        if k%120==0:
            mosq_sound.play()    
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                running = False 
            if event.type == pygame.MOUSEMOTION:
                gun_x_pos, gun_y_pos = pygame.mouse.get_pos()
            if event.type == pygame.MOUSEBUTTONDOWN:
                shot=shot-1
                gunsound.play()
                pygame.draw.circle(room,(0,0,0), (gun_x_pos,gun_y_pos),3)
                if abs(gun_x_pos-(mosq_x_pos+15))<15 and abs(gun_y_pos-(mosq_y_pos+15))<15 and m1dead==0:
                    m1dead=1
                    coin=coin+1000
                    coin_sound.play()
                    del mosq
                    m1dead_x=mosq_x_pos
                    m1dead_y=mosq_y_pos
                if abs(gun_x_pos-(mosq2_x_pos+15))<15 and abs(gun_y_pos-(mosq2_y_pos+15))<15 and m2dead==0:
                    m2dead=1
                    coin=coin+1000
                    coin_sound.play()
                    del mosq2
                    m2dead_x=mosq2_x_pos
                    m2dead_y=mosq2_y_pos
                if abs(gun_x_pos-(mosq3_x_pos+15))<15 and abs(gun_y_pos-(mosq3_y_pos+15))<15 and m3dead==0:
                    m3dead=1
                    coin=coin+1000
                    coin_sound.play()
                    del mosq3
                    m3dead_x=mosq3_x_pos
                    m3dead_y=mosq3_y_pos
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_l:
                    shortcut=shortcut+1
        if shortcut%7==0:
            coin=3000
            rooom=room
            phase=2
        
        #모기 움직임 설정
        def rand_move(a,b):
            a=a+randrange(1,30)-randrange(1,30)
            b=b+randrange(1,30)-randrange(1,30)
            return [a,b]
        [mosq_x_pos,mosq_y_pos]=rand_move(mosq_x_pos,mosq_y_pos)
        [mosq2_x_pos,mosq2_y_pos]=rand_move(mosq2_x_pos,mosq2_y_pos)
        [mosq3_x_pos,mosq3_y_pos]=rand_move(mosq3_x_pos,mosq3_y_pos)

        #화면 넘어감 방지 
        if mosq_x_pos<0:
            mosq_x_pos=100
        elif mosq_x_pos > screen_width-mosq_width:
            mosq_x_pos =screen_width-mosq_width 
        elif mosq_y_pos<0:
            mosq_y_pos=100
        elif mosq_y_pos > screen_height-mosq_width:
            mosq_y_pos =screen_height-mosq_width
        if mosq2_x_pos<0:
            mosq2_x_pos=100
        elif mosq2_x_pos > screen_width-mosq_width:
            mosq2_x_pos =screen_width-mosq_width 
        elif mosq2_y_pos<0:
            mosq2_y_pos=100
        elif mosq2_y_pos > screen_height-mosq_width:
            mosq2_y_pos =screen_height-mosq_width
        if mosq3_x_pos<0:
            mosq3_x_pos=100
        elif mosq3_x_pos > screen_width-mosq_width:
            mosq3_x_pos =screen_width-mosq_width 
        elif mosq3_y_pos<0:
            mosq3_y_pos=100
        elif mosq3_y_pos > screen_height-mosq_width:
            mosq3_y_pos =screen_height-mosq_width
        if gun_x_pos<0:
            gun_x_pos=0
        elif gun_x_pos > screen_width:
            gun_x_pos =screen_width
        elif gun_y_pos<0:
            gun_y_pos=0
        elif gun_y_pos > screen_height:
            gun_y_pos =screen_height  

        #배경설정, 모기 사망시 소멸처리, 게임오버조건 
        screen.blit(room,(0,0))
        screen.blit(blood,(m1dead_x,m1dead_y))
        screen.blit(blood,(m2dead_x,m2dead_y))
        screen.blit(blood,(m3dead_x,m3dead_y))
        show_text('bullets:'+str(shot),pygame.font.Font(None,30),screen,20,20)
        show_text('coins:'+str(coin),pygame.font.Font(None,30),screen,20,370)
        if event.type == pygame.MOUSEBUTTONDOWN:
            screen.blit(gun2,(gun_x_pos,gun_y_pos))
        else:
            screen.blit(gun,(gun_x_pos,gun_y_pos))
        if m1dead==0 :
            screen.blit(mosq,(mosq_x_pos,mosq_y_pos))
        if m2dead==0:
            screen.blit(mosq2,(mosq2_x_pos,mosq2_y_pos))
        if m3dead==0:
            screen.blit(mosq3,(mosq3_x_pos,mosq3_y_pos))
        if m1dead==1 and m2dead==1 and m3dead==1 :
            rooom=room
            phase=2
        if (shot<=0) :
            show_text('gameover',pygame.font.Font(None,150),screen,50,150)
            show_text('click the mouse to quit',pygame.font.Font(None,30),screen,150,300)
        if (shot<0):
            if event.type == pygame.MOUSEBUTTONDOWN:
                pygame.quit()
            elif event.type == pygame.MOUSEWHEEL:
                pygame.quit()
            #게임오버 사운드 추가 
        pygame.display.update()# 게임화면 다시그리기
        if phase!=0:
                break
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
if phase==2:
    import pygame
    from random import*
    from math import*
    pygame.init()
    screen_width = 600  #가로
    screen_height = 400 #세로크기
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto") #타이틀
    clock=pygame.time.Clock()
    moon=pygame.mixer.Sound("resources/sounds/문소리.mp3")
    #텍스트 설정
    def put(im,i):
        if i<10:
            im=pygame.image.load('resources/ani2/이름 없는 노트북 (1)-0'+str(i)+'.jpg')
        if i==19 or i==20 or i==23 or i==24 or i==27 or i==28:
            im=pygame.image.load( 'resources/ani2/이름 없는 노트북 (1)-'+str(i)+'.jpg')
        elif i>=10 and (i==19 or i==20 or i==23 or i==24 or i==27 or i==28)==False :
            im=pygame.image.load( 'resources/ani2/이름 없는 노트북 (1)-'+str(i)+'.jpg')
        im=pygame.transform.scale(im, (600,400))
        screen.blit(im,(0,0))
    k=0
    x=4
    phase=2
    a=1
    sp=0
    i=1
    running = True 
    while running:
        dt=clock.tick(60)
        k=k+1
        for event in pygame.event.get(): 
                if event.type == pygame.QUIT: 
                    running = False
         
        for i in range(1,18):
            if k>=x*i and k<x*(i+1):
                put (a,i)
            i+=1
        for i in range(19,29):
            if k>=10*(i-11.4) and k<10*(i-10.4):
                if i==19 or i==20 or i==23 or i==24 or i==27 or i==28:
                    im=rooom
                elif i>=10 and (i==19 or i==20 or i==23 or i==24 or i==27 or i==28)==False :
                    im=pygame.image.load( 'resources/ani2/이름 없는 노트북 (1)-'+str(i)+'.jpg')
                im=pygame.transform.scale(im, (600,400))
                screen.blit(im,(0,0))
        for i in range(30,59):
            if k>=8*(i+5.7) and k<8*(i+6.7):
                put (a,i)
            i+=1
        if k==0:
            moon.play()
        if k==540:
            phase=4
        if event.type == pygame.KEYUP:
                if event.key == pygame.K_l:
                    sp=sp+1
        if sp>5:
            phase=4
        pygame.display.update()# 게임화면 다시그리기
        if phase==4:
                break
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################

if phase==4:
    pygame.init()
    screen_width = 600 #가로
    screen_height = 400 #세로크기
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto")    
    #fps
    clock=pygame.time.Clock()
    #오브젝트 클래스 (러닝타임간 이미지 사이즈 변경시)
    class obj:
        def __init__(self):
            self.x = 0
            self.y = 0
            self.v = 0
        def put_img(self, address):
            if address[-3:] == "png":
                self.img = pygame.image.load(address).convert_alpha()
            else :
                self.img = pygame.image.load(address)
            self.sx, self.sy = self.img.get_size()
        def sizeset(self, sx, sy):
            self.img = pygame.transform.scale(self.img, (sx, sy))
            self.sx, self.sy = self.img.get_size()
        def disp(self):
            screen.blit(self.img, (self.x,self.y))
     #충돌       
    def collide(a, b):
        if (a.x+a.sx>=b.x)and(a.x<b.x+b.sx)and(a.y<b.y+b.sy)and(a.y+a.sy>b.y):
            return 1
        else:
            return 0
    #텍스트 설정
    def text(text, font, screen, x, y):
        textobj=font.render(text,True,(0,0,0),(255,255,255))
        textrect=textobj.get_rect()
        textrect.topleft=(x,y)
        screen.blit(textobj,textrect)
    #배경이미지
    x=0
    sky2=pygame.image.load("resources/images/sky2.png")
    game_over=0
    #캐릭터 초기 위치 및 크기
    cow = obj()
    cow.put_img("resources/images/cow_hangsun.png")
    cow.sizeset(50,50)
    cow.x,cow.y=(0,200)
    left,right,up,down=(0,0,0,0)
    cow.v=6
    cow_hp=100
    #무기 등 
    gunsound=pygame.mixer.Sound("resources/sounds/gunsound.mp3")
    lasers=[]
    laser_dead=0
    shoot = 0
    boom=obj()
    boom.put_img("resources/images/empty.png")

    #모기
    mosq=obj()
    mosq_hp=5
    mosq.put_img("resources/images/mosq.png")
    mosq.sizeset(100,80)
    mosq.x,mosq.y=(500,200)
    mosq1=obj()
    mosq1s=[]
    running = True 
    while running:
        dt=clock.tick(60) 
        t=0
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                running = False 
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    left=1
                elif  event.key == pygame.K_RIGHT:
                    right=1
                elif event.key == pygame.K_UP:
                    up=1
                elif  event.key == pygame.K_DOWN:
                    down=1
                elif  event.key == pygame.K_z:
                        shoot=1
                        gunsound.play()
                        laser=obj()
                        laser.put_img("resources/images/laser.png")
                        laser.sizeset(24,8)
                        laser.x=cow.x+cow.sx
                        laser.y=cow.y+cow.sy/2
                        laser.v=50
                        lasers.append(laser)
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT : 
                    left=0
                if event.key == pygame.K_RIGHT:
                    right=0
                if event.key == pygame.K_UP:
                    up=0
                if event.key == pygame.K_DOWN:
                    down=0
                elif event.key == pygame.K_n:
                    phase=7
        if left==1:
            cow.x-=cow.v
        if right==1:
            cow.x+=cow.v
        if up==1:
            cow.y-=cow.v
        if down==1:
            cow.y+=cow.v
        boom.x=mosq.x
        boom.y=mosq.y+randrange(1,40)
        #죽은총알처리
        deads = []
        for i in range(len(lasers)):
            l = lasers[i]
            l.x += l.v
            if l.x <= 0:
                deads.append(i)
        deads.reverse()
        for d in deads:
            del lasers[d]

        #작은모기생성
        if mosq_hp>0:
            if x%randrange(10,40,2)==0:
                mosq1 = obj()
                mosq1.put_img("resources/images/mosq2.png")
                mosq1.sizeset(30,30)
                mosq1.x = mosq.x-20
                mosq1.y = randrange(50,350) 
                mosq1.v = randrange(3,8)
                mosq1s.append(mosq1)
                

            if x%randrange(30,70)==0:
                mosq1 = obj()
                mosq1.put_img("resources/images/mosq2.png")
                mosq1.sizeset(30,30)
                mosq1.x = mosq.x-30
                mosq1.y = mosq.y+10 
                mosq1.v = 4
                mosq1s.append(mosq1)
                mosq1s.append(mosq1)
                mosq1s.append(mosq1)

        dead = []
        for i in range(len(mosq1s)):
            if mosq.y%2==1:
                m = mosq1s[i]
                m.x-= m.v
                m.y=(49*m.y+cow.y)/50
                if m.x < 0:
                    dead.append(i)
            elif mosq.y%2==0:
                m = mosq1s[i]
                m.sizeset(30,30)
                m.x-= m.v
                m.y+=randrange(10,30)-randrange(10,30)
                if m.x < 0:
                    dead.append(i)
        dead.reverse()
        for d in dead:
            del mosq1s[d]
       
        dl_list = []
        dm_list = []
        for i in range(len(lasers)):
            for j in range(len(mosq1s)):
                l = lasers[i]
                m = mosq1s[j]
                if collide(l,m)== 1:
                    dl_list.append(i)
                    dm_list.append(j)
                    
            if collide(l,mosq)==1:
                dl_list.append(i)
                mosq_hp=mosq_hp-1
                boom.put_img("resources/images/boom.png")
            else :
                boom.put_img("resources/images/empty.png")
                
        if collide(cow,mosq)==1 and mosq_hp>0:
                mosq_hp=mosq_hp+1
                cow_hp=cow_hp-1
                mosq.put_img("resources/images/mosq_attack.png")

        for i in range(len(mosq1s)):
            m=mosq1s[i]
            if collide(cow,m)==1 and mosq_hp>0:
                cow_hp=cow_hp-0.2

        dl_list = list(set(dl_list))
        dm_list = list(set(dm_list))
        dl_list.reverse()
        dm_list.reverse()

        try:
            for dl in dl_list:
                del lasers[dl]
            for dm in dm_list:
                del mosq1s[dm]
        except:
            pass
        #벽쿵방지
        if cow.x<0:
            cow.x=0
        elif cow.x > screen_width-cow.sx:
            cow.x =screen_width-cow.sx
        elif cow.y<0:
            cow.y=0
        elif cow.y > screen_height-cow.sy:
            cow.y =screen_height-cow.sy
        if mosq.y>350:
            mosq.y=350
        elif mosq.y<10:
            mosq.y=10
   
        #이미지 업로드
        screen.blit(sky2,(x,0))       
        if x>-2320:
            x=x-0.5
            if mosq_hp<=0:
                x=x-10
                mosq.put_img("resources/images/mosq_hp0.png")
                if coin<4000:
                    coin_sound.play()
                    coin=coin+2000
        if x<-2100:
            mosq.x=(9*mosq.x+370)/10
            mosq.y=(9*mosq.y+300)/10
            mosq.sizeset(mosq.sx,mosq.sy)
            if mosq.sy>0:
                mosq.sy=mosq.sy-1 
        if mosq_hp>=0:
            text(str(mosq_hp),pygame.font.Font(None,30),screen,550,10)    
        if cow_hp>0:
            text(str(round(cow_hp)),pygame.font.Font(None,30),screen,10,10)
        else : 
            text('gameover',pygame.font.Font(None,110),screen,100,150)
            cow.x=-1000
            cow.y=-1000
            game_over=game_over+1
            if game_over>120:
                break
        if mosq.sy==0:
            phase=7
            break
        if event.type == pygame.KEYUP:
                if event.key == pygame.K_n : 
                    coin=coin+2000
                    phase=7
                    break
        for l in lasers:
            l.disp()
        for m in mosq1s:
            m.disp()
        show_text('coins:'+str(coin),pygame.font.Font(None,30),screen,20,370)
        boom.disp()
        cow.disp()
        mosq.disp()
        mosq.y=mosq.y+randrange(1,30)-randrange(1,30)

        pygame.display.update()# 게임화면 다시그리기

##############################################################################################################################
####################################################################################################################
######################################################################################################################
#################################################################################
##############################################################################################################################
####################################################################################################################
######################################################################################################################
#################################################################################
if phase==7:
    import pygame
    from random import*
    from math import*
    pygame.init()
    screen_width = 600 #가로
    screen_height = 400 #세로크기
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto") #타이틀
    clock=pygame.time.Clock()
    jangjun=pygame.mixer.Sound("resources/sounds/총 장전 소리.mp3")
    mosq_sound=pygame.mixer.Sound("resources/sounds/mosq_sound.mp3")
    class obj:
            def __init__(self):
                self.x = 0
                self.y = 0
                self.v = 0
            def put_img(self, address):
                if address[-3:] == "png":
                    self.img = pygame.image.load(address).convert_alpha()
                else :
                    self.img = pygame.image.load(address)
                self.sx, self.sy = self.img.get_size()
            def sizeset(self, sx, sy):
                self.img = pygame.transform.scale(self.img, (sx, sy))
                self.sx, self.sy = self.img.get_size()
            def disp(self):
                screen.blit(self.img, (self.x,self.y))
    #텍스트 설정
    def show_text(text, font, screen, x, y):
        textobj=font.render(text,True,(0,0,0),(255,255,255))
        textrect=textobj.get_rect()
        textrect.topleft=(x,y)
        screen.blit(textobj,textrect)
    def put(x,i):
        if i<10:
            x=pygame.image.load('resources/ani3/이름 없는 노트북 (2)-0'+str(i)+'.jpg')
        elif i>=10:
            x=pygame.image.load( 'resources/ani3/이름 없는 노트북 (2)-'+str(i)+'.jpg')
        x=pygame.transform.scale(x, (600, 400))
        screen.blit(x,(0,0))
    k=0
    x=4
    a=1
    sk=0
    i=0
    running = True 
    while running:
        dt=clock.tick(60)
        k=k+1
        for event in pygame.event.get(): 
                if event.type == pygame.QUIT: 
                    running = False 
        for i in range(1,14):
            if k>=x*i and k<x*(i+1):
                put (a,i)
            i+=1
        if k==57:
            phase=8                   
        pygame.display.update()# 게임화면 다시그리기
        if phase==8:
                break
##############################################################################################################################
####################################################################################################################
######################################################################################################################
#################################################################################
if phase==8:
    import pygame
    from random import*
    from math import*
    pygame.init()
    phase=8
    screen_width = 1000
    screen_height = 800
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto")    
    clock=pygame.time.Clock()
    class obj:
            def __init__(self):
                self.x = 0
                self.y = 0
                self.v = 0
            def put_img(self, address):
                if address[-3:] == "png":
                    self.img = pygame.image.load(address).convert_alpha()
                else :
                    self.img = pygame.image.load(address)
                self.sx, self.sy = self.img.get_size()
            def sizeset(self, sx, sy):
                self.img = pygame.transform.scale(self.img, (sx, sy))
                self.sx, self.sy = self.img.get_size()
            def disp(self):
                screen.blit(self.img, (self.x-self.sx/2,self.y-self.sy/2))
    def collide(a, b):
                a_rect=a.img.get_rect()
                b_rect=b.img.get_rect()
                a_rect.left=a.x
                b_rect.left=b.x
                a_rect.top=a.y
                b_rect.top=b.y
                if a_rect.colliderect(b_rect):
                    return 1
                else:
                    return 0

        #텍스트 설정
    def text(text, font, screen, x, y):
            textobj=font.render(text,True,(0,0,0),(255,255,255))
            textrect=textobj.get_rect()
            textrect.topleft=(x,y)
            screen.blit(textobj,textrect)
        #배경이미지
    creep=pygame.image.load("resources/images/creep.png")
    creep = pygame.transform.scale(creep,(4000,3200))
    miro=pygame.image.load("resources/images/miro.png")
    miro = pygame.transform.scale(miro,(2000,1600))
    creep_x,creep_y=(-1300,-600)
    light=pygame.image.load("resources/images/light.png")
    light = pygame.transform.scale(light,(2800,1000))
    light2=pygame.transform.flip(light,1,0)
    light3=pygame.transform.rotate(light,90)
    light3= pygame.transform.scale(light3,(1100,2200))
    light4=pygame.image.load("resources/images/light4.png")
    light4= pygame.transform.scale(light4,(1100,2200))
    light45=pygame.image.load("resources/images/light45.png")
    light45= pygame.transform.scale(light45,(1100,2200))
    l45=0
        #캐릭터 초기 위치 및 크기
    cowl1=pygame.image.load("resources/images/cowl1-removebg-preview.png")
    cowl2=pygame.image.load("resources/images/cowl2-removebg-preview.png")
    cowr1=pygame.image.load("resources/images/cowr1-removebg-preview.png")
    cowr2=pygame.image.load("resources/images/cowr2-removebg-preview.png")
    cowf1=pygame.image.load("resources/images/cowf1-removebg-preview.png")
    cowf2=pygame.image.load("resources/images/cowf2-removebg-preview.png")
    cowb1=pygame.image.load("resources/images/cowb1-removebg-preview.png")
    cowb2=pygame.image.load("resources/images/cowb2-removebg-preview.png")
    cowb2_1=pygame.image.load("resources/images/cowb2-1-removebg-preview.png")
    cowl1 = pygame.transform.scale(cowl1,(40,50))
    cowl2 = pygame.transform.scale(cowl2,(40,50))
    cowr1 = pygame.transform.scale(cowr1,(40,50))
    cowr2 = pygame.transform.scale(cowr2,(40,50))
    cowf1 = pygame.transform.scale(cowf1,(40,50))
    cowf2 = pygame.transform.scale(cowf2,(40,50))
    cowb1 = pygame.transform.scale(cowb1,(40,50))
    cowb2 = pygame.transform.scale(cowb2,(40,50))
    cowb2_1 = pygame.transform.scale(cowb2_1,(40,50))
    cow = obj()
    cow.put_img("resources/images/cowr1-removebg-preview.png")
    cow.sizeset(50,50)
    cow.x,cow.y,cow.v=(screen_width/2,screen_height/2,10)
    left,right,up,down=(0,0,0,0)
    #무기 등 
    portion2=obj()
    portion2.put_img(("resources/images/portion.png"))
    portion2.sizeset(50,50)
    shield2=obj()
    shield2.put_img(("resources/images/shield2.png"))
    shield2.sizeset(50,50)  
    coin2=obj()
    coin2.put_img(("resources/images/coin.png"))
    coin2.sizeset(50,50)  
    portion2.x,portion2.y=(-2280,-800)
    shield2.x,shield2.y=(-670,-1970)
    lasers=[]
    mosq1s=[]
    empty=pygame.image.load(("resources/images/empty.png"))
    gun_sound=pygame.mixer.Sound("resources/sounds/gunsound.mp3")
    coin_sound=pygame.mixer.Sound("resources/sounds/Coin.wav")
    mosq_sound=pygame.mixer.Sound("resources/sounds/mosq_sound.mp3")
    laser=obj()
    laser.put_img("resources/images/bullet.png")
    laser.sizeset(15,15)
    laser.x=cow.x
    laser.y=cow.y
    laser2=pygame.transform.rotate(laser.img,90)
    t,k,game_over,ak,bk,ck,dk,coindel,s=(0,0,0,0,0,0,0,0,0) 
    portion,shield,bullet,sunbo,mines,m,zxcz=(0,0,0,0,0,0,0)
    pygame.event.poll()
    running = True 
    while running:
        k=k+1
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    left=1
                if  event.key == pygame.K_RIGHT:
                    right=1
                if event.key == pygame.K_UP:
                    up=1
                if  event.key == pygame.K_DOWN:
                    down=1
                if  event.key == pygame.K_z:
                    s=k+30
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT : 
                    left=0
                if event.key == pygame.K_RIGHT:
                    right=0
                if event.key == pygame.K_UP:
                    up=0
                if event.key == pygame.K_DOWN:
                    down=0
                if event.key == pygame.K_m:
                    phase=9
                if event.key == pygame.K_w and portion>0:
                    if cow_hp<100:
                        portion=portion-1
                        cow_hp=cow_hp+10+randrange(1,20)
                    if cow_hp>100:
                        cow_hp=100
    #작은모기생성
        if k%30==0:
            mosq1 = obj()
            mosq1.put_img("resources/images/mosq.png")
            mosq1.sizeset(30,30)
            mosq1.x = randrange(200,1600)
            mosq1.y = randrange(350,950) 
            mosq1.v = randrange(3,8)
            mosq1s.append(mosq1)      
        dead=[]                
        for i in range(len(mosq1s)):
            m = mosq1s[i] 
            if left==1:
                        if m!=0:
                            m.x+=cow.v
            if right==1:
                        if m!=0:
                            m.x-=cow.v
            if up==1:
                        if m!=0:
                            m.y+=cow.v
            if down==1:
                        if m!=0:
                            m.y-=cow.v
            if abs(m.x-cow.x)<400 and abs(m.y-cow.y)<400:
                if collide(cow,m)==1:
                    cow_hp=cow_hp-3
                    dead.append(i)
                if k%10<7:
                    if k%10<4:
                        m.x=m.x+(cow.x+randrange(-30,30)-m.x)/sqrt(pow((cow.x-m.x),2)+pow((cow.y-m.y),2))*randrange(2,7)
                        m.y=m.y+(cow.y+randrange(-30,30)-m.y)/sqrt(pow((cow.x-m.x),2)+pow((cow.y-m.y),2))*randrange(2,7)
                    else:
                        m.x=((195)*m.x+(5)*(cow.x+randrange(-30,30)))/200
                        m.y=((195)*m.y+(5)*(cow.y+randrange(-30,30)))/200
                else: 
                    m.x=m.x+randrange(-10,10)
                    m.y=m.y+randrange(-10,10) 
            else: 
                m.x=m.x+randrange(-15,15)
                m.y=m.y+randrange(-15,15) 
            if abs(m.x-cow.x)<100 and abs(m.y-cow.y)<100:
                mosq_sound.play(1,2000,400)

        dead.reverse()
        for d in dead:
            del mosq1s[d]
        if left==1:
            creep_x+=cow.v
            if k%20<10:
                cow.img=cowl1
            else:
                cow.img=cowl2
        if right==1:
            creep_x-=cow.v
            if k%20<10:
                cow.img=cowr1
            else:
                cow.img=cowr2   
        if up==1:
            creep_y+=cow.v
            if k%20<10:
                cow.img=cowb1
            else:
                cow.img=cowb2_1   
        if down==1:
            creep_y-=cow.v
            if k%20<10:
                cow.img=cowf1
            else:
                cow.img=cowf2  
        if  cow.y<1480 and cow.y>1530 and cow.x>1030 and cow.x<1100:
            phase=9
        #아이템
        if portion==0 and zxcz!=1:
            portion2.x,portion2.y=(creep_x+2800,creep_y+1225) 
            if collide(cow,portion2):
                portion=1
                zxcz=1
                coin_sound.play()
                del portion2
        if shield==0:
            shield2.x,shield2.y=(creep_x+2360,creep_y+1710)   
            if collide(cow,shield2):
                shield=1
                coin_sound.play()
                del shield2
        if coindel==0:
            coin2.x,coin2.y=(creep_x+2740,creep_y+2200)
            if collide(cow,coin2):
                coin+=randrange(2,8)*1000
                coin_sound.play()
                coindel=1
                del coin2
    
        #벽쿵방지
        if creep_x>-650:
            creep_x=-640
        if creep_x<-2380:
            creep_x=-2380
        if creep_y>-600:
            creep_y=-600
        if creep_y<-2080:
            creep_y=-2080
        f=750
        if abs(creep_y+f)<50 and (creep_x>-1270 or creep_x<-1430) :
            if cow.img==cowf1 or cow.img==cowf2:
                creep_y=-f+50
            elif cow.img==cowb1 or cow.img==cowb2_1:
                creep_y=-f-50
        f=970
        if abs(creep_y+f)<50 and (creep_x>-940 or creep_x<-990) and (creep_x>-1910 or creep_x<-2050) :
            if cow.img==cowf1 or cow.img==cowf2:
                creep_y=-f+50
            elif cow.img==cowb1 or cow.img==cowb2_1:
                creep_y=-f-50
        f=1200
        if abs(creep_y+f)<50 and (creep_x>-660 or creep_x<-840) and  (creep_x>-1540 or creep_x<-1690) and  (creep_x>-2080 or creep_x<-2330):
            if cow.img==cowf1 or cow.img==cowf2:
                creep_y=-f+50
            elif cow.img==cowb1 or cow.img==cowb2_1:
                creep_y=-f-50
        f=1440        
        if abs(creep_y+f)<50 and  (creep_x>-1530 or creep_x<-1690):
            if cow.img==cowf1 or cow.img==cowf2:
                creep_y=-f+50
            elif cow.img==cowb1 or cow.img==cowb2_1:
                creep_y=-f-50
        f=1690
        if abs(creep_y+f)<50 and  (creep_x>-200 or creep_x<-860) and  (creep_x>-2170 or creep_x<-2330) :
            if cow.img==cowf1 or cow.img==cowf2:
                creep_y=-f+50
            elif cow.img==cowb1 or cow.img==cowb2_1:
                creep_y=-f-50
        f=1900   
        if abs(creep_y+f)<50 and  (creep_x>-940 or creep_x<-1130) and  (creep_x>-1840 or creep_x<-2020):
            if cow.img==cowf1 or cow.img==cowf2:
                creep_y=-f+50
            elif cow.img==cowb1 or cow.img==cowb2_1:
                creep_y=-f-50

        if abs(creep_x+1430)<110 and  (creep_y<-980 and creep_y>-1190):
            if right==1:
                creep_x=-1430+110
            elif left==1:
                creep_x=-1430-110
        if abs(creep_x+1190)<50 and  (creep_y<-1220 and creep_y>-1440):
            if right==1:
                creep_x=-1190+50
            elif left==1:
                creep_x=-1190-50
        if abs(creep_x+1750)<80 and  (creep_y<-1220 and creep_y>-1440):
            if right==1:
                creep_x=-1750+80
            elif left==1:
                creep_x=-1750-80
        if abs(creep_x+2090)<60 and  (creep_y<-1700 and creep_y>-1890):
            if right==1:
                creep_x=-2090+60
            elif left==1:
                creep_x=-2090-60
        if abs(creep_x+1190)<60 and  (creep_y<-1900 and creep_y>-2130):
            if right==1:
                creep_x=-1190+60
            elif left==1:
                creep_x=-1190-60
        if abs(creep_x+1570)<30 and abs(creep_y+2080)<30:
            phase=9

        
        #이미지 업로드
        screen.blit(creep,(creep_x,creep_y))
        cow.disp()
        laser.disp()
        screen.blit(miro,(creep_x+1000,creep_y+1000))
        for m in mosq1s:
            m.disp()
        if portion==0 and zxcz!=1:
            portion2.disp()
        if shield==0:
            shield2.disp() 
        if coindel!=1:
            coin2.disp()
        
        if cow.img==cowl1 or cow.img== cowl2:
            screen.blit(light,(-1780,-80))
        elif cow.img==cowr1 or cow.img==cowr2:
            screen.blit(light2,(-20,-80))
        elif cow.img==cowf1 or cow.img==cowf2:
            screen.blit(light3,(-34,-20))
        elif cow.img==cowb1 or cow.img==cowb2_1:
            screen.blit(light4,(-60,-1400))
        else: screen.blit(light2,(-20,-80))
        # if l45==1:
        #     screen.blit(light45,(500,400))
        #     print(l45)
        a1=pygame.Surface.get_rect(light4)
        if k<s:
            text('you cannot shooting here',pygame.font.Font(None,50),screen,300,100)
        if cow_hp>0:
            text("hp:"+str(round(cow_hp))+",coins: "+str(coin)+", steam:"+str(t)+", portion:"+str(portion)+", sheild:"+str(shield)+", bullet:"+str(bullet)+", sunbo:"+str(sunbo)+", mines:"+str(mines),pygame.font.Font(None,30),screen,10,730)
        else : 
            text('gameover',pygame.font.Font(None,180),screen,100,150)
            cow.x=-1000
            cow.y=-1000
            game_over=game_over+1
            if game_over>120:
                break
        if phase==9:
            break
        pygame.display.update()# 게임화면 다시그리기
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
if phase==9:
    phase=9
    import pygame
    from random import*
    from math import*
    pygame.init()
    screen_width = 1000
    screen_height = 600
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto")    
    clock=pygame.time.Clock()
    class obj:
            def __init__(self):
                self.x = 0
                self.y = 0
                self.v = 0
            def put_img(self, address):
                if address[-3:] == "png":
                    self.img = pygame.image.load(address).convert_alpha()
                else :
                    self.img = pygame.image.load(address)
                self.sx, self.sy = self.img.get_size()
            def sizeset(self, sx, sy):
                self.img = pygame.transform.scale(self.img, (sx, sy))
                self.sx, self.sy = self.img.get_size()
            def disp(self):
                screen.blit(self.img, (self.x-self.sx/2,self.y-self.sy/2))
        
        #충돌       
    def collide(a, b):
            a_rect=a.img.get_rect()
            b_rect=b.img.get_rect()
            a_rect.left=a.x
            b_rect.left=b.x
            a_rect.top=a.y
            b_rect.top=b.y-10
            if a_rect.colliderect(b_rect):
                return 1
            else:
                return 0
        #텍스트 설정
    def text(text, font, screen, x, y):
            textobj=font.render(text,True,(0,0,0),(255,255,255))
            textrect=textobj.get_rect()
            textrect.topleft=(x,y)
            screen.blit(textobj,textrect)
        #배경이미지
    nest=pygame.image.load("resources/images/queens_nest.png")
    creep=pygame.image.load("resources/images/creep.png")
    creep = pygame.transform.scale(creep,(1000,600))
    how=pygame.image.load("resources/images/knowhow.png")
    grass=pygame.image.load("resources/images/grass.png")
    grass = pygame.transform.scale(grass,(1000,200))
    hally=pygame.image.load("resources/images/hally.png")
    hally = pygame.transform.scale(hally,(1000,600))
    gift=pygame.image.load("resources/images/gift_shop.png")
    gift = pygame.transform.scale(gift,(200,170))
    sunmul=pygame.image.load("resources/images/sunmul.png")
    sunmul = pygame.transform.scale(sunmul,(80,70))   
    graph=pygame.image.load("resources/images/giftgraph.png")
    graph = pygame.transform.scale(graph,(1000,600))
    grass2= pygame.transform.flip(grass,0,1)
    pc=pygame.image.load("resources/images/pc.png")
    pc = pygame.transform.scale(pc,(200,150))
    door=pygame.image.load("resources/images/door.png")
    door = pygame.transform.scale(door,(100,150))
    gayui=pygame.image.load("resources/images/gayui.png")
    gayui=pygame.transform.flip(gayui,1,0)
    bayui=pygame.image.load("resources/images/bayui.png")
    bo=pygame.image.load("resources/images/bo.png")
    so=pygame.image.load("resources/images/so.png")
    choose=0
    for i in [gayui,bayui,bo,so]:
        i = pygame.transform.scale(i,(300,200))
    garodeng=obj()
    garodeng.put_img("resources/images/garodeng.png")
    garodeng.sizeset(100,200)
    empty1=obj()
    empty1.put_img("resources/images/empty.png")
    empty1.sizeset(100,300)
    empty1.x,empty1.y=(900,-300)
    empty2=obj()
    empty2.put_img("resources/images/empty.png")
    empty2.sizeset(100,300)
    empty2.x,empty2.y=(900,600)
    
    cop=obj()
    cop.put_img("resources/images/cop.png")
    cop.sizeset(100,70)
    cop.x,cop.y=(-300,119)
    cop_sound=pygame.mixer.Sound("resources/sounds/cop_sound2.mp3")
    cop_hp=10
        #캐릭터 초기 위치 및 크기
    cowl1=pygame.image.load("resources/images/cowl1-removebg-preview.png")
    cowl2=pygame.image.load("resources/images/cowl2-removebg-preview.png")
    cowr1=pygame.image.load("resources/images/cowr1-removebg-preview.png")
    cowr2=pygame.image.load("resources/images/cowr2-removebg-preview.png")
    cowf1=pygame.image.load("resources/images/cowf1-removebg-preview.png")
    cowf2=pygame.image.load("resources/images/cowf2-removebg-preview.png")
    cowb1=pygame.image.load("resources/images/cowb1-removebg-preview.png")
    cowb2=pygame.image.load("resources/images/cowb2-removebg-preview.png")
    cowb2_1=pygame.image.load("resources/images/cowb2-1-removebg-preview.png")
    cowl1 = pygame.transform.scale(cowl1,(40,50))
    cowl2 = pygame.transform.scale(cowl2,(40,50))
    cowr1 = pygame.transform.scale(cowr1,(40,50))
    cowr2 = pygame.transform.scale(cowr2,(40,50))
    cowf1 = pygame.transform.scale(cowf1,(40,50))
    cowf2 = pygame.transform.scale(cowf2,(40,50))
    cowb1 = pygame.transform.scale(cowb1,(40,50))
    cowb2 = pygame.transform.scale(cowb2,(40,50))
    cowb2_1 = pygame.transform.scale(cowb2_1,(40,50))
    cow = obj()
    cow.put_img("resources/images/cowr1-removebg-preview.png")
    cow.sizeset(50,50)
    cow.x,cow.y,cow.v=(30,200,4)
    left,right,up,down=(0,0,0,0)
    bobu=obj()
    bobu.put_img("resources/images/bobusang.png")
    bobu.sizeset(40,50)
    bobu2=pygame.image.load("resources/images/bobu2.png")
    buy2=pygame.image.load("resources/images/bobu2_1.jpg")
    bobu2 = pygame.transform.scale(bobu2,(50,40))
    bobu.x,bobu.y=(580,100)
    bobu_hp=0
    buy=pygame.image.load("resources/images/buy.jpg")
    chungsan=pygame.image.load("resources/images/chungsan.jpg")
    #무기 등 
    shop=obj()
    shop.put_img("resources/images/shop.png")
    shop.sizeset(200,200)
    shop.x,shop.y=(550,60)
    lasers=[]
    empty=pygame.image.load(("resources/images/empty.png"))
    gun_sound=pygame.mixer.Sound("resources/sounds/gunsound.mp3")
    laser=obj()
    laser.put_img("resources/images/bullet.png")
    laser.sizeset(15,15)
    laser.x=cow.x
    laser.y=cow.y
    tik=obj()
    tik.put_img("resources/images/tikb.png")
    tik.sizeset(10,0)
    tik.x=990
    tik.y=300
    tiks=[tik]
    tikr=obj()
    tikr.put_img("resources/images/tik.png")
    po=1
    laser2=pygame.transform.rotate(laser.img,90)
    t,k,game_over,ak,bk,ck,dk,asd,police,dobak,qwer,up1,up2,up3=(0,0,0,0,0,0,0,0,0,0,0,0,0,0) 
    boyu,danga,masu,mado,poo,rever,ck,rev,col1,col2=(0,0,0,0,0,0,0,1,1,1)
    pygame.event.poll()
    running = True 
    while running:
        if tiks[len(tiks)-1]==tik:
            hyun=tik.y+tik.sy
        else:
            hyun=tikr.y
        k=k+1
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    left=1
                elif  event.key == pygame.K_RIGHT:
                    right=1
                elif event.key == pygame.K_UP:
                    up=1
                elif  event.key == pygame.K_DOWN:
                    down=1
                elif  event.key == pygame.K_z and cow.img==cowb1:
                    shoot=1
                    gun_sound.play()
                    laser=obj()
                    laser.put_img("resources/images/laser.png")
                    laser.sizeset(24,8)
                    laser.x=cow.x
                    laser.y=cow.y-5
                    laser.v=50
                    lasers.append(laser)
                elif event.key == pygame.K_w and portion>0:
                    if cow_hp<100:
                        portion=portion-1
                        cow_hp=cow_hp+10+randrange(1,20)
                    if cow_hp>100:
                        cow_hp=100
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT : 
                    left=0
                if event.key == pygame.K_RIGHT:
                    right=0
                if event.key == pygame.K_UP:
                    up=0
                if event.key == pygame.K_DOWN:
                    down=0
        if left==1:
            cow.x-=cow.v
            if k%20<10:
                cow.img=cowl1
            else:
                cow.img=cowl2
        if right==1:
            cow.x+=cow.v
            if k%20<10:
                cow.img=cowr1
            else:
                cow.img=cowr2   
        if up==1:
            cow.y-=cow.v
            if k%20<10:
                cow.img=cowb1
            else:
                cow.img=cowb2_1   
        if down==1:
            cow.y+=cow.v
            if k%20<10:
                cow.img=cowf1
            else:
                cow.img=cowf2  
        if cow.y<110 and cow.x<360 and cow.x>300:
            pc_open=1
        elif cow.y<120 and cow.y>105 and cow.x<610 and cow.x>590:
            shop_open=1
        if  cow.y<280 and cow.y>240 and cow.x>890:
            phase=10
        if cow.x >700 and cow.x < 713 and cow.y<=105 and k%10==0 and 700+tiks[0].y-hyun>0: 
            po=randrange(1,3)
            if tiks[len(tiks)-1]==tikr:
                tikr.y=tikr.y-poo
            if po==2:
                tik=obj()
                tik.put_img("resources/images/tikb.png")
                tiks.append(tik)
                tik.sizeset(10,1)
                if 1000+tiks[0].y-300-hyun>1300:
                    tik.x,tik.y=(990,hyun+randrange(-50,0))
                else:
                    tik.x,tik.y=(990,hyun+randrange(-80,0))
            else:
                tikr=obj()
                tikr.put_img("resources/images/tik.png")
                tiks.append(tikr)                
                tikr.sizeset(10,1)
                tikr.x,tikr.y=(990,hyun+randrange(0,80)-poo)
        #보부상 이스터에그 
        if bobu_hp>15 and asd<k:
            shield=shield+10000
            portion=portion+100000  
            asd=k+600000
            coin=coin+100000
        deads = []
        for i in range(len(lasers)):
            l = lasers[i]
            if cow.img==cowb1 or cow.img==cowb2_1:
                laser.img=laser2
                l.y -= l.v
            if l.x <= 0 or l.x>1000 or l.y<0 or l.y>600:
                laser.img=empty
                deads.append(i)
        for d in deads:
            del lasers[d]     
        dl_list = []
        dl_list = list(set(dl_list))
        for i in range(len(lasers)):
            l=lasers[i]
            if collide(l,bobu)== 1:
                laser.img=empty
                bobu_hp+=1
                dl_list.append(i)
            if collide(l,cop)==1:
                laser.img=empty
                cop_hp-=1
                coin=coin+1000
                dl_list.append(i)
        dl_list=list(set(dl_list))
        dl_list.reverse()
        try:
            for dl in dl_list:
                del lasers[dl]
        except:
            pass
        if collide(cow,bobu)==1 and bobu_hp>20:
            cow_hp-=1
        if bobu_hp>20:
            bobu.img=bobu2
            bobu.x=(19*bobu.x+1*cow.x)/20
            bobu.y=(19*bobu.y+1*cow.y)/20
            
        #벽쿵방지
        if cow.x<0:
            cow.x=0
        elif cow.x > 950-cow.sx:
            cow.x =950-cow.sx
        elif cow.y<100:
            cow.y=100
        elif cow.y > 400-cow.sy:
            cow.y =400-cow.sy
        #이미지 업로드
        screen.blit(creep,(0,0))  
        screen.blit(grass,(0,0))   
        screen.blit(grass2,(0,400))   
        for i in range(0,1200,200):
            screen.blit(garodeng.img,(i,-100)) 
        screen.blit(nest,(800,0))
        screen.blit(door,(830,140))  
        screen.blit(pc,(250,-30))
        shop.disp()
        bobu.disp()
        screen.blit(gift,(630,-40))
        screen.blit(sunmul,(670,60))
        cow.disp()
        laser.disp()  
        for i in range(0,1200,200):
            screen.blit(garodeng.img,(i-70,300))
        if cow.x >700 and cow.x < 713 and cow.y<=105:
            if 700+tiks[0].y-hyun<=0:
                hyun=700+tiks[0].y
                boyu=0
            screen.blit(graph,(0,0))
            if event.type == pygame.MOUSEBUTTONDOWN :
                a,b=pygame.mouse.get_pos()
                if a>310 and a<380 and b>370 and b<410 and coin>1000-hyun and (1000+tiks[0].y-300-hyun)<coin:
                    masu=1
                if a>400 and a<480 and b>370 and b<410 and boyu>0:
                    mado=1
                if a>0 and a<150 and b>0 and b<80 and coin>550 and rev==1 and boyu==0:
                    rever=1
                if a>0 and a<150 and b>0 and b<80 and coin>550 and rev==5:
                    rever=1
            if boyu==0:
                danga=0
            if event.type == pygame.MOUSEBUTTONUP :
                a,b=pygame.mouse.get_pos()
                if a>310 and a<380 and b>370 and b<410 and masu==1:
                    if tiks[len(tiks)-1]==tikr:  
                        danga=(danga*boyu+(1000+tiks[0].y-300-hyun))/(boyu+1)
                        coin-=round(1000+tiks[0].y-300-hyun,0)
                    else:
                        danga=(danga*boyu+(1000+tiks[0].y-300-hyun))/(boyu+1)
                        coin-=round(1000+tiks[0].y-300-hyun,0)
                    boyu=boyu+1
                    masu=0
                if a>400 and a<480 and b>370 and b<410 and boyu>0 and mado==1:
                    if rev==1:
                        if tiks[len(tiks)-1]==tik:  
                            coin+=round(1000+tiks[0].y-300-hyun,0)
                        else:
                            coin+=round(1000+tiks[0].y-300-hyun,0)
                    if rev==5:
                        if tiks[len(tiks)-1]==tik:  
                            coin+=round(700-hyun+tiks[0].y+(1000+tiks[0].y-300-hyun-danga)*4,0)
                        else:
                            coin+=round(700-hyun+tiks[0].y+(1000+tiks[0].y-300-hyun-danga)*4,0)
                    boyu=boyu-1
                    mado=0
                
                if a>0 and a<150 and b>0 and b<100 and coin>550 and rev==1 and rever==1:
                    rev=5
                    rever=0
                if a>0 and a<150 and b>0 and b<100 and coin>550 and rev==5 and rever==1:
                    rev=1
                    rever=0
            
            if 700+tiks[0].y-hyun>0:
                poo=randrange(2,125)
                if po ==2:
                    if (700+tiks[0].y-hyun)>1300:
                        tik.sizeset(10,poo*1.5)
                    else:
                        tik.sizeset(10,poo)
                else:
                    tikr.sizeset(10,poo)
                for i in range(len(tiks)):
                    tk=tiks[i]
                    if collide(tikr,empty1)==1:
                        tk.y+=8
                    elif collide(tik,empty2)==1:
                        tk.y-=8
                    if k%10==0:
                        tk.x-=13  
                if tiks[len(tiks)-1]==tik:
                    for tk in tiks:
                        screen.blit(tk.img,(tk.x,tk.y))
                elif tiks[len(tiks)-1]==tikr: 
                    for tk in tiks[:len(tiks)-1]:
                        screen.blit(tk.img,(tk.x,tk.y))
                    screen.blit(tikr.img,(tikr.x,tikr.y-poo))
            else: 
                text('The gift shop eventually got delisted. ',pygame.font.Font(None,70),screen,40,300)
            text('x'+str(rev),pygame.font.Font(None,80),screen,0,0)
            if rev==5:
                if tiks[len(tiks)-1]==tik:  
                    if danga*0.8-(1000+tiks[0].y-300-hyun)>=0 and boyu>0 and ck<k:
                        boyu=0
                        ck=k+50
            if ck>k and (1000+tiks[0].y-300-hyun)>30:
                screen.blit(chungsan,(0,0))
            if boyu>0:
                text(str(danga),pygame.font.Font(None,50),screen,410,415)
            text(str(boyu),pygame.font.Font(None,50),screen,410,460)
            text(str(round(1000+tiks[0].y-300-hyun)),pygame.font.Font(None,60),screen,700,370) 
        if cow.x>317 and cow.x<327 and cow.y<=100:
            screen.blit(hally,(0,0))
            if qwer<k:
                choose,dobak=(0,0)
            if choose==0:
                text('rock',pygame.font.Font(None,100),screen,400,0)
                text('scissors',pygame.font.Font(None,100),screen,350,100)
                text('papal',pygame.font.Font(None,100),screen,400,200)
            if event.type == pygame.MOUSEBUTTONDOWN : 
                mouse_x,mouse_y=pygame.mouse.get_pos()
                if mouse_x>400 and mouse_x<600 and mouse_y>0 and mouse_y<80:
                    up1=1
                    up2=k+30
                if mouse_x>350 and mouse_x<750 and mouse_y>100 and mouse_y<180:
                    up1=1
                if mouse_x>400 and mouse_x<650 and mouse_y>200 and mouse_y<280:
                    up1=1
                    up2=k+30
            if event.type == pygame.MOUSEBUTTONUP and dobak==0 and up1==1:
                    dobak=randrange(1,4)
                    qwer=k+30   
                    sc=k+30 
            if dobak==1 and qwer>k:
                screen.blit(bayui,(0,200))
                screen.blit(so,(500,200))
                if sc>k and up2>k:
                    text('your hand can only throw scissor',pygame.font.Font(None,70),screen,130,100)
                if qwer==k+30:
                    coin=coin-2000
                if coin<0:
                    police=1
                    coin=0
                    cow.x=300
                    cow.y=cow.y-20
                choose=1
                up1=0
            if dobak==2 and qwer>k:
                screen.blit(gayui,(0,200))
                screen.blit(so,(500,200))  
                if sc>k and up2>k:
                    text('please look at your hand bro',pygame.font.Font(None,70),screen,130,100)  
                choose=1
                up1=0
            if dobak==3 and qwer>k:
                screen.blit(bo,(0,200))
                screen.blit(so,(500,200)) 
                if sc>k and up2>k:
                    text('please look at your hand bro',pygame.font.Font(None,70),screen,130,100)   
                if qwer==k+30:
                    coin=coin+1000
                choose=1
                up1=0
        if cop_hp<0:
            police=0
            cop.x=-300
        if police==1 and cop.x<310 and (abs(cow.x-cop.x)<20 and abs(cow.y-cop.y)<20)==False:
                cop_sound.play(1,7000,1000)
                cop.x+=7
        if abs(cow.x-cop.x)<30 and abs(cow.y-cop.y)<30:
            cow_hp=0
        cop.disp()
        if collide(cow,bobu)==1 and bobu_hp<20:
            screen.blit(buy,(0,0))
            if event.type == pygame.MOUSEBUTTONDOWN and t==0 :
                ak=k+100
                coin=coin-1000
                t=1
            if ak>k :
                text('you have to upgrade steampack, you have no choice',pygame.font.Font(None,50),screen,20,150) 
            if event.type == pygame.MOUSEBUTTONDOWN and t==1 and sunbo==0 and ak<k:
                bk=k+100
                coin=coin-1000
                sunbo=1
            if bk>k and sunbo==1:
                text('you have to upgrade sunbo, you have no choice',pygame.font.Font(None,50),screen,20,150)
            if event.type == pygame.MOUSEBUTTONDOWN and t==1 and  sunbo==1 and mines==0 and bk<k :
                ck=k+100
                coin=coin-1000
                mines=1
            if ck>k and mines==1:
                text('you have to upgrade mine, you have no choice',pygame.font.Font(None,50),screen,20,150)
            if coin<1:
                screen.blit(buy2,(0,0))
                text('get out',pygame.font.Font(None,180),screen,100,150)
                cow.x=cow.x-1
                cow.y=cow.y-1
            if event.type == pygame.MOUSEMOTION:
                a,b=pygame.mouse.get_pos()
                if a>400 and a<480 and b>20 and b<310:
                    screen.blit(how,(600,0))
            if event.type == pygame.MOUSEBUTTONDOWN :
                a,b=pygame.mouse.get_pos()
                if a>400 and a<480 and b>190 and b<240 and mines==1:
                    portdown=1 
                if a>400 and a<480 and b>260 and b<310 and mines==1:
                    portdown=1
            if event.type == pygame.MOUSEBUTTONUP :
                a,b=pygame.mouse.get_pos()
                if a>400 and a<480 and b>190 and b<240 and mines==1 and portdown==1 and coin>=1000:
                    coin-=1000
                    portion+=1
                    portdown=0
                if a>400 and a<480 and b>260 and b<310 and mines==1 and portdown==1 and coin>=1000:
                    coin-=1000
                    shield+=1
                    portdown=0
            
        if cow_hp>0:
            text("hp:"+str(round(cow_hp))+",coins: "+str(coin)+", steam:"+str(0)+", portion:"+str(portion)+", sheild:"+str(shield)+", bullet:"+str(bullet)+", sunbo:"+str(sunbo)+", mines:"+str(mines),pygame.font.Font(None,30),screen,10,540)
        else : 
            text('gameover',pygame.font.Font(None,180),screen,100,150)
            cow.x=-1000
            cow.y=-1000
            game_over=game_over+1
            if game_over>120:
                break
        if phase==10:
            break
        pygame.display.update()# 게임화면 다시그리기
##################################################################################################################################
##################################################################################################################################
##################################################################################################################################
##################################################################################################################################
##################################################################################################################################





if phase==10:
    import pygame
    from random import*
    from math import*
    pygame.init()
    screen_width = 800 #가로
    screen_height = 800 #세로크기
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto")    
    clock=pygame.time.Clock()
        #오브젝트 클래스 (러닝타임간 이미지 사이즈 변경시)
    class obj:
            def __init__(self):
                self.x = 0
                self.y = 0
                self.v = 0
            def put_img(self, address):
                if address[-3:] == "png":
                    self.img = pygame.image.load(address).convert_alpha()
                else :
                    self.img = pygame.image.load(address)
                self.sx, self.sy = self.img.get_size()
            def sizeset(self, sx, sy):
                self.img = pygame.transform.scale(self.img, (sx, sy))
                self.sx, self.sy = self.img.get_size()
            def disp(self):
                screen.blit(self.img, (self.x-self.sx/2,self.y-self.sy/2))

        #충돌       
    def collide(a, b):
            a_rect=a.img.get_rect()
            b_rect=b.img.get_rect()
            a_rect.left=a.x
            b_rect.left=b.x
            a_rect.top=a.y
            b_rect.top=b.y
            if a_rect.colliderect(b_rect):
                return 1
            else:
                return 0
        #각도설정 
    def tan(a,b):
        if a.x<b.x and (b.y-a.y)/(b.x-a.x+0.001)<1 and (b.y-a.y)/(b.x-a.x+0.001)>-1:
            return 1
        if a.x>b.x and (a.y-b.y)/(b.x-a.x+0.001)<=1 and (a.y-b.y)/(b.x-a.x+0.001)>=-1:
            return 3
        if b.y<=a.y and ((a.y-b.y)/(b.x-a.x+0.001)>1 or (a.y-b.y)/(b.x-a.x+0.001)<-1):
            return 2
        if b.y>a.y and ((a.y-b.y)/(b.x-a.x+0.001)>=1 or (a.y-b.y)/(b.x-a.x+0.001))<=-1:
            return 4
        
        #텍스트 설정
    def text(text, font, screen, x, y):
            textobj=font.render(text,True,(0,0,0),(255,255,255))
            textrect=textobj.get_rect()
            textrect.topleft=(x,y)
            screen.blit(textobj,textrect)
        #배경이미지
    chair=pygame.image.load("resources/images/chair.png")
    creep=pygame.image.load("resources/images/creep.png")
    garodeng=pygame.image.load("resources/images/garodeng.png")
        #캐릭터 초기 위치 및 크기
    cowl1=pygame.image.load("resources/images/cowl1-removebg-preview.png")
    cowl2=pygame.image.load("resources/images/cowl2-removebg-preview.png")
    cowr1=pygame.image.load("resources/images/cowr1-removebg-preview.png")
    cowr2=pygame.image.load("resources/images/cowr2-removebg-preview.png")
    cowf1=pygame.image.load("resources/images/cowf1-removebg-preview.png")
    cowf2=pygame.image.load("resources/images/cowf2-removebg-preview.png")
    cowb1=pygame.image.load("resources/images/cowb1-removebg-preview.png")
    cowb2=pygame.image.load("resources/images/cowb2-removebg-preview.png")
    cowb2_1=pygame.image.load("resources/images/cowb2-1-removebg-preview.png")
    cowl1 = pygame.transform.scale(cowl1,(40,50))
    cowl2 = pygame.transform.scale(cowl2,(40,50))
    cowr1 = pygame.transform.scale(cowr1,(40,50))
    cowr2 = pygame.transform.scale(cowr2,(40,50))
    cowf1 = pygame.transform.scale(cowf1,(40,50))
    cowf2 = pygame.transform.scale(cowf2,(40,50))
    cowb1 = pygame.transform.scale(cowb1,(40,50))
    cowb2 = pygame.transform.scale(cowb2,(40,50))
    cowb2_1 = pygame.transform.scale(cowb2_1,(40,50))
    cow = obj()
    cow.put_img("resources/images/cowl1-removebg-preview.png")
    cow.sizeset(40,50)
    cow.x,cow.y=(350,1000)
    left,right,up,down=(0,0,0,0)
    cow.v=4
    cow_sound=pygame.mixer.Sound("resources/sounds/cow_sound.mp3")
    move=0
    #무기 등 
    laser=obj()
    laser.put_img("resources/images/bullet.png")
    laser.sizeset(15,15)
    laser.x=cow.x
    laser.y=cow.y
    mine=obj()
    mine.put_img("resources/images/mine.png")
    mine.sizeset(50,50)
    boom=obj()
    boom.put_img("resources/images/bullet.png")
    boom_sound=pygame.mixer.Sound("resources/sounds/boom.mp3")
    steampack=pygame.mixer.Sound("resources/sounds/steampack.mp3")
    shield_img=obj()
    shield_img.put_img("resources/images/shield.png")
    shield_img.sizeset(50,50)
    mp=obj()
    mp.put_img("resources/images/mp.png")
    kal=obj()
    kal.put_img("resources/images/kal.png")
    kal.sizeset=(90,90)
    mouse_x,mouse_y=(0,0)
    gunsound=pygame.mixer.Sound("resources/sounds/gunsound.mp3")
    lasers=[]
    laser_dead=0
    bunno=1
    k,a,t,rm1,rm2,q,d_chair,s_on,bullet_time,d,d_time,shoot,game_over=(0,0,0,0,0,0,0,0,0,0,0,0,0)
    minetime,boomtime,bull_x,bull_y=(0,0,0,0)
    #k=프레임변수(시간활용)
        #모기
    mosq=obj()
    mosq_sound=pygame.mixer.Sound("resources/sounds/mosq_sound.mp3")
    mosq_hp=150
    mosq.put_img("resources/images/mosqueen.png")
    mosq.sizeset(100,80)
    mosq.x,mosq.y=(400,70)
    mosq1=obj()
    mosq1s=[]
    chim=obj()
    chim.put_img("resources/images/chim.png")
    chim.sizeset(20,20)
    chim2=obj()
    chim2.img=pygame.transform.flip(chim.img,1,0)
    chim2.sizeset(30,20)
    chim.put_img("resources/images/chim.png")
    chim.sizeset(30,20)
    chim3=obj()
    chim3.put_img("resources/images/chim3.png")
    chim3.sizeset(100,50)
    chim4=obj()
    chim4.img=pygame.transform.flip(chim3.img,0,1)
    chim4.sizeset(100,50)
    pygame.event.poll()
    running = True 
    while running:
        k=k+1
        if k%100==0 and game_over==0:
            chim.x=780
            chim.y=randrange(20,780)
            chim2.x=20
            chim2.y=randrange(20,780)
        if k%180==0 and mosq.y<cow.y and game_over==0:
            chim3.x = mosq.x
            chim3.y=mosq.y+80
        elif k%180==0 and mosq.y>cow.y and game_over==0:
            chim4.x=mosq.x
            chim4.y=mosq.y-80
        chim3.y=chim3.y+10
        chim4.y=chim4.y-10    
        chim2.x=chim2.x+10
        chim.x=chim.x-10
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button==3 : 
                mouse_x,mouse_y=pygame.mouse.get_pos()
                move=True
                mp.x=mouse_x
                mp.y=mouse_y
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    a=1
                if event.key == pygame.K_t and t<3 and cow_hp>10:
                    cow_hp=cow_hp-10
                    cow.v=cow.v+4
                    t=t+1
                    steampack.play()
                if event.key == pygame.K_e and shield>0:
                    shield=shield-1
                    s_on=k+100
                if event.key == pygame.K_q and sunbo==1:
                    d=1
                if event.key == pygame.K_w and portion>0:
                    if cow_hp<100:
                        portion=portion-1
                        cow_hp=cow_hp+10+randrange(1,20)
                    if cow_hp>100:
                        cow_hp=100
                if event.key == pygame.K_r and mines>0:
                    mines=mines-1
                    mine.x=cow.x
                    mine.y=cow.y
                    minetime=k+180
            if event.type == pygame.MOUSEBUTTONDOWN and d==1:
                move=False
                cow.x=mp.x
                cow.y=mp.y
                shield_img.x=cow.x
                shield_img.y=cow.y
                d=0
                sunbo=0
                d_time=k+180
            if event.type == pygame.MOUSEBUTTONDOWN and a==1 and bullet==1:
                move=False
                mouse_x,mouse_y=pygame.mouse.get_pos()
                bull_x,bull_y=(mouse_x,mouse_y)
                gunsound.play()
                laser.x=cow.x
                laser.y=cow.y
                laser.v=50
                lasers.append(laser)
                a=0
                bullet=0
                bullet_time=k+30
            if a==1 and pygame.MOUSEBUTTONDOWN:    
                mp.x,mp.y=pygame.mouse.get_pos()
            if d==1 and pygame.MOUSEBUTTONDOWN:    
                mp.x,mp.y=pygame.mouse.get_pos()
            
        if t>0 and (k%300==0):
            t=t-1
            cow.v=cow.v-4 
        if k>s_on:
            s_on=0
        if minetime<k:
            mines=1
        if bullet_time<k:
            bullet=1
        if d_time<k:
            sunbo=1
        if move==True:
            cow.x=cow.x+(mouse_x-cow.x)/sqrt(pow((cow.x-mouse_x),2)+pow((cow.y-mouse_y),2)+0.001)*cow.v
            cow.y=cow.y+(mouse_y-cow.y)/sqrt(pow((cow.x-mouse_x),2)+pow((cow.y-mouse_y),2)+0.001)*cow.v
            if tan(cow,mp)==3 and k%20<10:
                cow.img=cowl1
            if tan(cow,mp)==3 and k%20>=10:
                cow.img=cowl2
            if tan(cow,mp)==1 and k%20<10:
                cow.img=cowr1
            if tan(cow,mp)==1 and k%20>=10:
                cow.img=cowr2
            if tan(cow,mp)==4 and k%20<10:
                cow.img=cowf1
            if tan(cow,mp)==4 and k%20>=10:
                cow.img=cowf2
            if tan(cow,mp)==2 and k%20<10:
                cow.img=cowb1
            if tan(cow,mp)==2 and k%20>=10:
                cow.img=cowb2_1
            if s_on!=0:
                shield_img.x=cow.x
                shield_img.y=cow.y
        if shoot==True:
                laser=obj()
                laser.put_img("resources/images/bullet.png")
                laser.sizeset(10,10)
                laser.x=cow.x
                laser.y=cow.y
                laser.v=1
                lasers.append(laser)
        laser.x += round(laser.v*(bull_x-cow.x)/sqrt(pow((cow.x-bull_x),2)+pow((cow.y-bull_y),2)+0.001))
        laser.y += round(laser.v*(bull_y-cow.y)/sqrt(pow((cow.x-bull_x),2)+pow((cow.y-bull_y),2)+0.001))
        
        #탄환 모기충돌, 폭발이미지, 플레이어 모기
        deads = []
        for i in range(len(lasers)):
            l = lasers[i]
            if l.x <= 10 or l.x>780 or l.y<10 or l.y>780:
                deads.append(i)
            if collide (laser,mosq)==1:
                deads.append(i)
                if t==0:
                    mosq_hp=mosq_hp-2
                else:
                    mosq_hp=mosq_hp-3*t
        deads.reverse()
        for d in deads:
            del lasers[d]     
        boom.x=mosq.x+randrange(-30,30)
        boom.y=mosq.y+randrange(-20,20)
        if collide(mine,mosq)==1:
            boom_sound.play()
            boom.x=mine.x
            boom.y=mine.y
            boomtime=k+30
            mine.x=1000
            mine.y=1000
        if boomtime>k:
            mosq_hp=mosq_hp-1
            boom.put_img("resources/images/boom.png")   
            boom.sizeset(80,80) 
        if collide(laser,mosq)==1:
            if t==0:
                mosq_hp=mosq_hp-2
            else:
                mosq_hp=mosq_hp-3*t    
            boom.put_img("resources/images/boom.png")
        elif boomtime<k : 
            boom.put_img("resources/images/empty.png")
        if collide(cow,mosq)==1:
            if s_on==0 and mosq_hp>0:    
                cow_hp=cow_hp-1   
                mosq_hp=mosq_hp+1 
                mosq.put_img("resources/images/mosqueen_attack.png")
        else:
            mosq.put_img("resources/images/mosqueen.png")
            for i in [chim,chim2,chim3,chim4]:
                if collide(cow,i)==1:
                    cow_hp=cow_hp-1
        #벽쿵방지
        if cow.x<100:
            cow.x=100
        elif cow.x > 700-cow.sx:
            cow.x =700-cow.sx
        elif cow.y<0:
            cow.y=0
        elif cow.y > 800-cow.sy:
            cow.y =800-cow.sy
        if mosq.y>750:
            mosq.y=750
        elif mosq.y<10:
            mosq.y=10
        if mosq.x>650:
            mosq.x=650
        elif mosq.x<110:
            mosq.x=110
        if mosq_hp<40 and mosq_hp>0:
            mosq.put_img("resources/images/mosqueen_40.png") 
        elif mosq_hp<=0:
            mosq.put_img("resources/images/mosq_dead.png") 
            mosq.sizeset(100,80)

        #이미지 업로드
        screen.blit(creep,(0,0))
        if d_chair==0:
            screen.blit(chair,(325,0))
        if (laser.x>300 and laser.x<450 and laser.y<100):
            d_chair=1
        for i in range(0,800,200) :
            screen.blit(garodeng,(0,i))
        for i in range(0,800,200) :
            screen.blit(garodeng,(700,i))
        mosq2_img=pygame.transform.flip(mosq.img,1,0)
        if mosq.x<cow.x:
            mosq.img=mosq2_img
        for l in lasers:
            l.disp()
        mine.disp() 
        chim.disp() 
        chim2.disp()    
        chim3.disp()
        chim4.disp()
        mp.disp()
        cow.disp()
        if s_on!=0:
            shield_img.disp()
        mosq.disp()
        boom.disp()
        # 모기 움직임 (플레이어 방향 난수 섞어서)
        if k%240>57 and k%240<117:
            bunno=7
            mosq_sound.play(1,1000,100)
        else:
            bunno=1
        if k>50 and game_over==0:
            if s_on>k and collide(mosq,cow)==1:
                bunno=-40
                mosq_hp=mosq_hp-1
            if k%10==0:
                rm1=randrange(-8,8)
                rm2=randrange(-12,12)
            random9=randrange(1,10)
            if random9<3:
                mosq.x=((197-bunno)*mosq.x+(3+bunno)*cow.x)/200+rm1
                mosq.y=((197-bunno)*mosq.y+(3+bunno)*cow.y)/200+rm2
            elif random9<8 :
                mosq.x=mosq.x+rm1
                mosq.y=mosq.y+rm2
            else:
                mosq.x=mosq.x+(cow.x-mosq.x)/sqrt(pow((cow.x-mosq.x),2)+pow((cow.y-mosq.y),2))*randrange(1,4)*bunno+rm1
                mosq.y=mosq.y+(cow.y-mosq.y)/sqrt(pow((cow.x-mosq.x),2)+pow((cow.y-mosq.y),2))*randrange(1,4)*bunno+rm2
        if mosq_hp>=0:
            text("hp:"+str(mosq_hp),pygame.font.Font(None,30),screen,550,10)    
        else : 
            game_over=game_over+1
            if game_over>120:
                phase=11
                break  
        if cow_hp>0:
            text("Q sunbo:"+str(sunbo)+",W portion:"+str(portion)+",E sheild:"+str(shield),pygame.font.Font(None,30),screen,10,740)
            text("R mines:"+str(mines)+",T steam:"+str(t),pygame.font.Font(None,30),screen,10,760)
            text("hp:"+str(round(cow_hp)),pygame.font.Font(None,30),screen,700,740)
            text( "bullet="+str(bullet),pygame.font.Font(None,30),screen,700,760)
        else : 
            text('gameover',pygame.font.Font(None,180),screen,100,150)
            cow.x=-1000
            cow.y=-1000
            game_over=game_over+1
            if game_over==3:
                cow_sound.play()
            if game_over>120:
                break
        pygame.display.update()# 게임화면 다시그리기
################################################################################
######################################################################################
##########################################################################################
if phase==11:
    import pygame
    from random import*
    from math import*
    pygame.init()
    screen_width = 800 #가로
    screen_height = 800 #세로크기
    screen=pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("moskillto") #타이틀
    clock=pygame.time.Clock()
    gun=pygame.mixer.Sound("resources/sounds/gunsound.mp3")
    class obj:
            def __init__(self):
                self.x = 0
                self.y = 0
                self.v = 0
            def put_img(self, address):
                if address[-3:] == "png":
                    self.img = pygame.image.load(address).convert_alpha()
                else :
                    self.img = pygame.image.load(address)
                self.sx, self.sy = self.img.get_size()
            def sizeset(self, sx, sy):
                self.img = pygame.transform.scale(self.img, (sx, sy))
                self.sx, self.sy = self.img.get_size()
            def disp(self):
                screen.blit(self.img, (self.x,self.y))
    #텍스트 설정
    def show_text(text, font, screen, x, y):
        textobj=font.render(text,True,(0,0,0),(255,255,255))
        textrect=textobj.get_rect()
        textrect.topleft=(x,y)
        screen.blit(textobj,textrect)
    def put(x,i):
        if i<10:
            x=pygame.image.load( 'resources/ani4/이름 없는 노트북 (2)-0'+str(i)+'.jpg')
        elif i>=10:
            x=pygame.image.load('resources/ani4/이름 없는 노트북 (2)-'+str(i)+'.jpg')
        x=pygame.transform.scale(x, (800, 800))
        screen.blit(x,(0,0))
    k=0
    x=4
    a=1
    sk=0
    i=0
    running = True 
    while running:
        dt=clock.tick(60)
        k=k+1
        for event in pygame.event.get(): 
                if event.type == pygame.QUIT: 
                    running = False 
        for i in range(1,38):
            if k>=x*i and k<x*(i+1):
                put (a,i)
            i+=1
        if k==150:
            gun.play()
        if k==190:
            show_text('victory',pygame.font.Font(None,150),screen,240,300)
        if k==350:
                break      
        pygame.display.update()# 게임화면 다시그리기





pygame.quit()

